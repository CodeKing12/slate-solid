import { isHotkey } from "is-hotkey";
import { IS_APPLE } from "./environment";

/**
 * Hotkey mappings for each platform.
 */

const HOTKEYS = {
	bold: "mod+b",
	compose: ["down", "left", "right", "up", "backspace", "enter"],
	moveBackward: "left",
	moveForward: "right",
	moveWordBackward: "ctrl+left",
	moveWordForward: "ctrl+right",
	deleteBackward: "shift?+backspace",
	deleteForward: "shift?+delete",
	extendBackward: "shift+left",
	extendForward: "shift+right",
	italic: "mod+i",
	insertSoftBreak: "shift+enter",
	splitBlock: "enter",
	undo: "mod+z",
};

const APPLE_HOTKEYS = {
	moveLineBackward: "opt+up",
	moveLineForward: "opt+down",
	moveWordBackward: "opt+left",
	moveWordForward: "opt+right",
	deleteBackward: ["ctrl+backspace", "ctrl+h"],
	deleteForward: ["ctrl+delete", "ctrl+d"],
	deleteLineBackward: "cmd+shift?+backspace",
	deleteLineForward: ["cmd+shift?+delete", "ctrl+k"],
	deleteWordBackward: "opt+shift?+backspace",
	deleteWordForward: "opt+shift?+delete",
	extendLineBackward: "opt+shift+up",
	extendLineForward: "opt+shift+down",
	redo: "cmd+shift+z",
	transposeCharacter: "ctrl+t",
};

const WINDOWS_HOTKEYS = {
	deleteWordBackward: "ctrl+shift?+backspace",
	deleteWordForward: "ctrl+shift?+delete",
	redo: ["ctrl+y", "ctrl+shift+z"],
};

/**
 * Create a platform-aware hotkey checker.
 */

const create = (key: string) => {
	const generic = HOTKEYS[<keyof typeof HOTKEYS>key];
	const apple = APPLE_HOTKEYS[<keyof typeof APPLE_HOTKEYS>key];
	const windows = WINDOWS_HOTKEYS[<keyof typeof WINDOWS_HOTKEYS>key];
	const isGeneric = generic && isHotkey(generic);
	const isApple = apple && isHotkey(apple);
	const isWindows = windows && isHotkey(windows);

	return (event: KeyboardEvent) => {
		if (isGeneric && isGeneric(event)) return true;
		if (IS_APPLE && isApple && isApple(event)) return true;
		if (!IS_APPLE && isWindows && isWindows(event)) return true;
		return false;
	};
};

/**
 * Hotkeys.
 */

export default {
	isBold: create("bold"),
	isCompose: create("compose"),
	isMoveBackward: create("moveBackward"),
	isMoveForward: create("moveForward"),
	isDeleteBackward: create("deleteBackward"),
	isDeleteForward: create("deleteForward"),
	isDeleteLineBackward: create("deleteLineBackward"),
	isDeleteLineForward: create("deleteLineForward"),
	isDeleteWordBackward: create("deleteWordBackward"),
	isDeleteWordForward: create("deleteWordForward"),
	isExtendBackward: create("extendBackward"),
	isExtendForward: create("extendForward"),
	isExtendLineBackward: create("extendLineBackward"),
	isExtendLineForward: create("extendLineForward"),
	isItalic: create("italic"),
	isMoveLineBackward: create("moveLineBackward"),
	isMoveLineForward: create("moveLineForward"),
	isMoveWordBackward: create("moveWordBackward"),
	isMoveWordForward: create("moveWordForward"),
	isRedo: create("redo"),
	isSoftBreak: create("insertSoftBreak"),
	isSplitBlock: create("splitBlock"),
	isTransposeCharacter: create("transposeCharacter"),
	isUndo: create("undo"),
};

