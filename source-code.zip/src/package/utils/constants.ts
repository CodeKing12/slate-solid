export const TRIPLE_CLICK = 3
